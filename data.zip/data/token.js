// const data = 'xoxb-4254826744641-4278730625360-oG25xISZhLkfHBUuoEpOtgNF';// dragoni
const data = 'xoxb-4254826744641-4391453774211-LDnvr4wjwdm3dKkTSzl8fi3c';// girfriend
// const data = 'xoxb-4254826744641-4329136628306-eKSggOHuY2X8MawU8lxwQspM';// 26
function getToken() {
  return data;
}

module.exports.getToken = getToken;
